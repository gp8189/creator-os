/* eslint-disable no-unused-vars */
import { useState, useEffect } from "react";

const C = {
  bg:"#0f1210", sur:"#161d18", card:"#1c2620", bor:"#2a3830",
  a1:"#e8836a", a2:"#c4614a", a3:"#7ab88a", a4:"#f0b87a", a5:"#a8d4b0",
  tx:"#f5f0ec", mu:"#7a9080", dn:"#e07060"
};

function useLS(key, defaultVal) {
  const [val, setVal] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      return stored ? JSON.parse(stored) : defaultVal;
    } catch { return defaultVal; }
  });
  useEffect(() => {
    try { window.localStorage.setItem(key, JSON.stringify(val)); }
    catch(e) { console.log(e); }
  }, [key, val]);
  return [val, setVal];
}

const DEF_PILLARS = [
  {id:1,name:"Storytelling",color:"#e8836a",emoji:"🎭",description:"Cinematic fiction, drama, cliffhangers"},
  {id:2,name:"Education",color:"#7ab88a",emoji:"💡",description:"Tips, facts, insider knowledge"},
  {id:3,name:"Behind Scenes",color:"#a8d4b0",emoji:"🎬",description:"Day in the life, process"},
  {id:4,name:"Monetization",color:"#f0b87a",emoji:"💰",description:"CTAs, product plugs"},
  {id:5,name:"Community",color:"#c4614a",emoji:"🤝",description:"Q&A, engagement, trends"},
];
const PLATS = ["TikTok","Instagram Reels","YouTube Shorts","Pinterest","Facebook","Podcast"];
const STATS = ["Idea","Scripting","Filming","Editing","Scheduled","Published","Repurposed"];
const SC = {Idea:"#7a9080",Scripting:"#e8836a",Filming:"#c4614a",Editing:"#f0b87a",Scheduled:"#7ab88a",Published:"#a8d4b0",Repurposed:"#d4c4a8"};
const MTYPES = ["Digital Product","Affiliate Link","Brand Deal","Course","Coaching","Membership","Merch","Services"];

const DEF_POSTS = [
  {id:1,title:"The Passenger in 14C",pillar:1,platform:"TikTok",status:"Published",hook:"She handed me a folded note right before we landed...",caption:"Some passengers leave tips. She left something else.",hashtags:"#flightattendant #storytime #fyp",cta:"Follow for Part 2",date:"2025-04-01",views:"142K",likes:"18.2K",comments:"934",shares:"4.1K",monetize:"",revenue:"",notes:""},
  {id:2,title:"Why I Left My 9-5 for 36K ft",pillar:3,platform:"TikTok",status:"Scheduled",hook:"I was making 6 figures. Then I quit.",caption:"The real reason FAs don't quit",hashtags:"#flightattendant #quitmyjob",cta:"Save this",date:"2025-04-05",views:"",likes:"",comments:"",shares:"",monetize:"Digital Product",revenue:"",notes:""},
];
const DEF_PRODUCTS = [
  {id:1,name:"Crew Lounge Script Bundle",type:"Digital Product",price:27,platform:"Gumroad",status:"Live",sales:43,revenue:1161,description:"10 viral FA fiction scripts"},
  {id:2,name:"Faceless Content Course",type:"Course",price:197,platform:"Teachable",status:"In Progress",sales:0,revenue:0,description:"Build a 6-figure faceless brand"},
];
const DEF_GOALS = [
  {id:1,label:"TikTok Followers",current:4800,target:10000,unit:"followers",emoji:"🎯",deadline:"2025-05-31"},
  {id:2,label:"Monthly Revenue",current:2161,target:5000,unit:"$",emoji:"💸",deadline:"2025-05-31"},
  {id:3,label:"Posts Published",current:12,target:30,unit:"posts",emoji:"📱",deadline:"2025-04-30"},
  {id:4,label:"Email List",current:210,target:1000,unit:"subscribers",emoji:"📧",deadline:"2025-06-30"},
];
const DEF_NOTES = [
  {id:1,title:"Brand Voice Bible",tags:["branding"],color:"#e8836a",pinned:true,content:"The Crew Lounge speaks like a seasoned FA — witty, warm, mysterious. Never desperate. Always in control.\n\nTone: Conversational but cinematic\nAvoid: Clichés, filler phrases",date:"2025-04-01"},
  {id:2,title:"Script Ideas Dump",tags:["scripts"],color:"#7ab88a",pinned:true,content:"- Passenger who recognized me from viral video\n- Medical emergency over the Pacific\n- Why I never eat airplane food\n- Unwritten rules of first class",date:"2025-04-02"},
  {id:3,title:"Affiliate Programs",tags:["monetize"],color:"#f0b87a",pinned:false,content:"☐ Amazon Associates\n☐ Skyscanner\n☐ Away Luggage\n☐ Audible\n☐ NordVPN",date:"2025-04-03"},
];
const DEF_AFFILIATES = [
  {id:1,name:"Amazon Associates",niche:"Travel Gear",comm:"4-8%",status:"Active",clicks:284,conv:12,rev:140,notes:"Great for luggage"},
  {id:2,name:"Away Luggage",niche:"Luggage",comm:"10%",status:"Pending",clicks:0,conv:0,rev:0,notes:"Applied — waiting"},
  {id:3,name:"Skyscanner",niche:"Travel Booking",comm:"$0.80/click",status:"Active",clicks:1200,conv:88,rev:320,notes:"High converter"},
];
const DEF_DEALS = [
  {id:1,brand:"TravelPro Luggage",type:"Gifted + Commission",value:400,status:"Active",deliverables:"2 TikToks + 1 Reel",deadline:"2025-05-15",contact:"partnerships@travelpro.com",notes:"Code: CREW10"},
];
const DEF_REVENUE = [
  {id:1,date:"2025-04-01",source:"Script Bundle",type:"Digital Product",amount:729,notes:"27 sales"},
  {id:2,date:"2025-04-03",source:"Skyscanner",type:"Affiliate Link",amount:120,notes:""},
  {id:3,date:"2025-04-05",source:"Media Kit",type:"Services",amount:500,notes:"TravelPro"},
];
const DEF_BRAND = {
  name:"The Crew Lounge",handle:"@seat1a",tagline:"36,000 feet of unfiltered truth.",
  mission:"To entertain, educate, and inspire through cinematic faceless storytelling.",
  voice:"Witty, warm, mysterious, cinematic. Never desperate. Always in control.",
  audience:"Women 22-38. Travel enthusiasts, aspiring FAs, drama lovers.",
  colors:"#e8836a salmon, #7ab88a sage green",avoid:"Clichés, filler words, face reveals",
  hooks:"She told me something I wasn't supposed to hear.",
  ctas:"Follow for Part 2 / Save this / Link in bio",
  hashtags:"#flightattendant #cabincrew #storytime #facelesscreator #fyp",
  posting:"TikTok: 5-7x/week · Reels: 3-4x/week",
  usp:"The only faceless FA account blurring fiction and real experience."
};
const DEF_PERSONAS = [
  {id:1,name:"Aspiring Aviator",age:"22-28",gender:"Female",location:"USA, UK, Australia",pain:"Wants to become a FA but doesn't know how",desires:"Insider knowledge, inspiration",content:"Application tips, training stories",buys:"Script bundles, career guides"},
  {id:2,name:"Travel Drama Fan",age:"25-38",gender:"Female",location:"USA, Canada, Europe",pain:"Craves good stories",desires:"Cinematic addictive storytelling",content:"Fiction, cliffhangers",buys:"Shares and grows audience"},
];

function uid(){return Date.now()+Math.random().toString(36).slice(2);}
function pct(c,t){return Math.min(100,Math.round((c/t)*100));}
function fmt(n){if(!n&&n!==0)return"—";if(n>=1e6)return(n/1e6).toFixed(1)+"M";if(n>=1000)return(n/1000).toFixed(1)+"K";return String(n);}
function fd(n){if(!n&&n!==0)return"—";return"$"+Number(n).toLocaleString();}

const NAV = [
  {s:"Overview",items:[{id:"dash",ic:"✦",l:"Dashboard"},{id:"goals",ic:"🎯",l:"Goals"}]},
  {s:"Content",items:[{id:"planner",ic:"📝",l:"Content Planner"},{id:"cal",ic:"📅",l:"Calendar"},{id:"pillars",ic:"🏛",l:"Pillars"},{id:"scripts",ic:"🎬",l:"Scripts"}]},
  {s:"Monetize",items:[{id:"products",ic:"💰",l:"Products"},{id:"affiliates",ic:"🔗",l:"Affiliates"},{id:"deals",ic:"🤝",l:"Brand Deals"},{id:"revenue",ic:"📈",l:"Revenue"}]},
  {s:"Brand",items:[{id:"brand",ic:"✨",l:"Brand Hub"},{id:"audience",ic:"👥",l:"Personas"}]},
  {s:"Tools",items:[{id:"agent",ic:"🤖",l:"AI Agent"},{id:"notes",ic:"📓",l:"Smart Notes"}]},
];

const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:${C.bg};color:${C.tx};font-family:'DM Sans',sans-serif}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:${C.sur}}::-webkit-scrollbar-thumb{background:${C.bor};border-radius:3px}
input,textarea,select,button{font-family:'DM Sans',sans-serif}button{cursor:pointer}
.shell{display:flex;min-height:100vh}
.sb{width:220px;min-height:100vh;background:${C.sur};border-right:1px solid ${C.bor};display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:100;overflow-y:auto}
.logo{padding:20px 16px 14px;border-bottom:1px solid ${C.bor}}
.logo h1{font-family:'Cormorant Garamond',serif;font-size:21px;background:linear-gradient(135deg,${C.a1},${C.a3});-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700}
.logo p{font-size:10px;color:${C.mu};margin-top:2px}
.logo .sb2{font-size:9px;margin-top:5px;color:${C.a3}}
.snav{padding:8px 0;flex:1}
.ssec{padding:0 9px 5px}
.sslbl{font-size:9px;font-weight:600;color:${C.mu};letter-spacing:.12em;text-transform:uppercase;padding:6px 7px 2px}
.ni{display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:6px;font-size:12.5px;font-weight:500;color:${C.mu};transition:all .15s;margin-bottom:1px;border:none;background:none;width:100%;text-align:left;cursor:pointer}
.ni:hover{background:${C.card};color:${C.tx}}
.ni.on{background:linear-gradient(135deg,${C.a1}22,${C.a3}11);color:${C.tx};border:1px solid ${C.a1}40}
.main{margin-left:220px;flex:1;padding:24px 28px;max-width:1100px}
.ph h2{font-family:'Cormorant Garamond',serif;font-size:32px;font-weight:700;margin-bottom:3px}
.ph p{font-size:12px;color:${C.mu};margin-bottom:20px}
.glow{background:linear-gradient(135deg,${C.a1},${C.a3});-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.card{background:${C.card};border:1px solid ${C.bor};border-radius:10px;padding:16px}
.ct{font-size:10px;font-weight:600;color:${C.mu};text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.ga{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.sg{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}
.sc{background:${C.card};border:1px solid ${C.bor};border-radius:12px;padding:16px;transition:transform .2s}
.sc:hover{transform:translateY(-2px)}
.pb{height:5px;background:${C.bor};border-radius:99px;overflow:hidden;margin:5px 0 3px}
.pf{height:100%;border-radius:99px;background:linear-gradient(90deg,${C.a1},${C.a3});transition:width .5s}
.tag{display:inline-flex;align-items:center;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600}
.badge{padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600}
.tw{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:left;padding:8px 12px;font-size:10px;font-weight:600;color:${C.mu};text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid ${C.bor};white-space:nowrap}
td{padding:10px 12px;border-bottom:1px solid ${C.bor}15;vertical-align:middle}
tr:hover td{background:${C.sur}55}
.btn{display:inline-flex;align-items:center;gap:5px;padding:7px 13px;border-radius:7px;font-size:12px;font-weight:600;border:none;transition:all .15s}
.bp{background:linear-gradient(135deg,${C.a1},${C.a2});color:#fff}
.bp:hover{opacity:.9;transform:translateY(-1px)}
.bg2{background:${C.bor}44;color:${C.tx};border:1px solid ${C.bor}}
.bg2:hover{background:${C.bor}}
.bsm{padding:4px 9px;font-size:11px;border-radius:5px}
.bdn{background:${C.dn}18;color:${C.dn};border:1px solid ${C.dn}28}
.inp{background:${C.sur};border:1px solid ${C.bor};border-radius:7px;padding:7px 10px;color:${C.tx};font-size:12px;width:100%;outline:none;transition:border-color .15s}
.inp:focus{border-color:${C.a1}70}
.inp::placeholder{color:${C.mu}}
.ta{resize:vertical;min-height:70px}
select.inp{cursor:pointer}
.fl{font-size:10px;font-weight:600;color:${C.mu};text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;display:block}
.fg{margin-bottom:11px}
.fr{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.ov{position:fixed;inset:0;background:#000a;backdrop-filter:blur(3px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:16px}
.md{background:${C.card};border:1px solid ${C.bor};border-radius:13px;width:100%;max-width:640px;max-height:90vh;overflow-y:auto;padding:24px;animation:su .18s ease}
.mh{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
.mh h3{font-family:'Cormorant Garamond',serif;font-size:21px;font-weight:700}
@keyframes su{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
.divx{height:1px;background:${C.bor};margin:14px 0}
.tabs{display:flex;gap:3px;background:${C.sur};padding:3px;border-radius:8px;border:1px solid ${C.bor};width:fit-content;flex-wrap:wrap;margin-bottom:16px}
.tab{padding:5px 12px;border-radius:5px;font-size:11px;font-weight:500;color:${C.mu};cursor:pointer;border:none;background:none;transition:all .15s}
.tab.on{background:${C.card};color:${C.tx};box-shadow:0 1px 5px #00000028}
.nc{background:${C.card};border:1px solid ${C.bor};border-radius:10px;padding:14px;cursor:pointer;transition:all .2s}
.nc:hover{transform:translateY(-2px)}
.bf{background:${C.sur};border:1px solid ${C.bor};border-radius:7px;padding:10px 12px;margin-bottom:8px}
.bfl{font-size:9px;font-weight:700;color:${C.mu};text-transform:uppercase;letter-spacing:.1em;margin-bottom:2px}
.empty{text-align:center;padding:36px;color:${C.mu}}
.nce{background:${C.sur};border:1px solid ${C.bor};border-radius:7px;padding:12px;color:${C.tx};font-size:13px;width:100%;resize:vertical;line-height:1.65;outline:none;font-family:'DM Sans',sans-serif}
.chat-wrap{display:flex;flex-direction:column;height:calc(100vh - 200px);min-height:400px}
.chat-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:10px;background:${C.sur};border-radius:10px;margin-bottom:12px;border:1px solid ${C.bor}}
.msg{max-width:85%;padding:10px 14px;border-radius:10px;font-size:13px;line-height:1.6;white-space:pre-wrap;word-break:break-word}
.msg.user{background:${C.a1}22;border:1px solid ${C.a1}33;align-self:flex-end}
.msg.ai{background:${C.card};border:1px solid ${C.bor};align-self:flex-start}
.ai-label{font-size:9px;font-weight:700;color:${C.a3};text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px}
.chat-inp{background:${C.sur};border:1px solid ${C.bor};border-radius:8px;padding:10px 12px;color:${C.tx};font-size:13px;flex:1;resize:none;outline:none;min-height:44px;font-family:'DM Sans',sans-serif}
.qb{padding:5px 11px;border-radius:20px;font-size:11px;font-weight:500;border:1px solid ${C.a1}44;background:${C.a1}11;color:${C.a1};cursor:pointer;margin:3px}
@media(max-width:820px){.g2{grid-template-columns:1fr}.main{padding:14px}.sb{width:185px}.main{margin-left:185px}}
`;

function Modal({title, onClose, children, wide}) {
  return (
    <div className="ov" onClick={onClose}>
      <div className="md" style={wide ? {maxWidth:700} : {}} onClick={e => e.stopPropagation()}>
        <div className="mh">
          <h3>{title}</h3>
          <button className="btn bg2 bsm" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function FF({label, children}) {
  return <div className="fg"><label className="fl">{label}</label>{children}</div>;
}

function Sidebar({pg, setPg}) {
  return (
    <div className="sb">
      <div className="logo">
        <h1>Creator OS</h1>
        <p>✈ The Crew Lounge</p>
        <div className="sb2">💾 Auto-saves to your device</div>
      </div>
      <nav className="snav">
        {NAV.map(sec => (
          <div className="ssec" key={sec.s}>
            <div className="sslbl">{sec.s}</div>
            {sec.items.map(i => (
              <button key={i.id} className={`ni${pg === i.id ? " on" : ""}`} onClick={() => setPg(i.id)}>
                <span style={{fontSize:14}}>{i.ic}</span>{i.l}
              </button>
            ))}
          </div>
        ))}
      </nav>
      <div style={{padding:"10px",borderTop:`1px solid ${C.bor}`,fontSize:9,color:C.mu,textAlign:"center"}}>Creator OS v2.0</div>
    </div>
  );
}

function Dash({posts, prods, goals, nav}) {
  const rev = prods.reduce((s,p) => s + (Number(p.revenue)||0), 0);
  const pub = posts.filter(p => p.status === "Published").length;
  return (
    <div>
      <div className="ph">
        <h2>Good morning, <span className="glow">Marisol</span> ✦</h2>
        <p>Your creator empire — all data saves automatically to this device.</p>
      </div>
      <div className="sg">
        {[
          {e:"📱", v:posts.length, l:"Posts Tracked", c:C.a1},
          {e:"💰", v:fd(rev), l:"Total Revenue", c:C.a3},
          {e:"✅", v:pub, l:"Published", c:C.a5},
          {e:"📅", v:posts.filter(p => p.status === "Scheduled").length, l:"Scheduled", c:C.a4},
          {e:"✍️", v:posts.filter(p => ["Idea","Scripting"].includes(p.status)).length, l:"In Pipeline", c:C.a2},
          {e:"📦", v:prods.filter(p => p.status === "Live").length, l:"Live Products", c:C.a4},
        ].map((s,i) => (
          <div className="sc" key={i} style={{borderColor:s.c+"28"}}>
            <div style={{fontSize:20,marginBottom:6}}>{s.e}</div>
            <div style={{fontSize:24,fontWeight:700,color:s.c,fontFamily:"'Cormorant Garamond',serif"}}>{s.v}</div>
            <div style={{fontSize:11,color:C.mu,marginTop:2}}>{s.l}</div>
          </div>
        ))}
      </div>
      <div className="g2">
        <div className="card">
          <div className="ct">Recent Posts</div>
          {posts.slice(0,5).map(p => (
            <div key={p.id} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 0",borderBottom:`1px solid ${C.bor}18`}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:12,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.title}</div>
                <div style={{fontSize:10,color:C.mu}}>{p.platform} · {p.date||"No date"}</div>
              </div>
              <span className="badge" style={{background:(SC[p.status]||"#888")+"20",color:SC[p.status]||"#888"}}>{p.status}</span>
            </div>
          ))}
          <button className="btn bg2 bsm" style={{marginTop:9}} onClick={() => nav("planner")}>View All →</button>
        </div>
        <div className="card">
          <div className="ct">Goals at a Glance</div>
          {goals.map(g => (
            <div key={g.id} style={{marginBottom:11}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                <span style={{fontSize:11}}>{g.emoji} {g.label}</span>
                <span style={{fontSize:11,fontWeight:700,color:C.a1}}>{pct(g.current,g.target)}%</span>
              </div>
              <div className="pb"><div className="pf" style={{width:`${pct(g.current,g.target)}%`}}/></div>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.mu}}>
                <span>{g.unit==="$" ? fd(g.current) : `${fmt(g.current)} ${g.unit}`}</span>
                <span>/ {g.unit==="$" ? fd(g.target) : `${fmt(g.target)} ${g.unit}`}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Goals({goals, setGoals}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() {
    const it = {...f, current:Number(f.current), target:Number(f.target)};
    if (!f.id) setGoals(p => [...p, {...it, id:uid()}]);
    else setGoals(p => p.map(g => g.id === it.id ? it : g));
    setM(null);
  }
  return (
    <div>
      <div className="ph"><h2>Goals & Metrics</h2><p>Track every milestone — auto-saved.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({label:"",current:0,target:100,unit:"followers",emoji:"🎯",deadline:""}); setM(1); }}>+ Add Goal</button>
      <div className="ga">
        {goals.map(g => (
          <div className="card" key={g.id} style={{borderColor:C.a1+"28"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
              <span style={{fontSize:24}}>{g.emoji}</span>
              <div>
                <div style={{fontSize:13,fontWeight:600}}>{g.label}</div>
                <div style={{fontSize:10,color:C.mu}}>{g.deadline ? `Due: ${g.deadline}` : "No deadline"}</div>
              </div>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
              <div style={{fontSize:22,fontWeight:700,fontFamily:"'Cormorant Garamond',serif",color:C.a1}}>{g.unit==="$" ? fd(g.current) : fmt(g.current)}</div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:11,color:C.mu}}>of {g.unit==="$" ? fd(g.target) : `${fmt(g.target)} ${g.unit}`}</div>
                <div style={{fontWeight:700,color:C.a3}}>{pct(g.current,g.target)}%</div>
              </div>
            </div>
            <div className="pb"><div className="pf" style={{width:`${pct(g.current,g.target)}%`}}/></div>
            <div style={{display:"flex",gap:6,marginTop:10}}>
              <button className="btn bg2 bsm" onClick={() => { setF({...g}); setM(1); }}>Edit</button>
              <button className="btn bdn bsm" onClick={() => setGoals(p => p.filter(x => x.id !== g.id))}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      {m && <Modal title={f.id ? "Edit Goal" : "Add Goal"} onClose={() => setM(null)}>
        <div className="fr">
          <FF label="Emoji"><input className="inp" value={f.emoji||""} onChange={F("emoji")}/></FF>
          <FF label="Label"><input className="inp" value={f.label||""} onChange={F("label")}/></FF>
        </div>
        <div className="fr">
          <FF label="Current"><input className="inp" type="number" value={f.current||""} onChange={F("current")}/></FF>
          <FF label="Target"><input className="inp" type="number" value={f.target||""} onChange={F("target")}/></FF>
        </div>
        <div className="fr">
          <FF label="Unit"><input className="inp" value={f.unit||""} onChange={F("unit")} placeholder="followers / $"/></FF>
          <FF label="Deadline"><input className="inp" type="date" value={f.deadline||""} onChange={F("deadline")}/></FF>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save Goal</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Planner({posts, setPosts, pillars}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const [fil, setFil] = useState("All");
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  const empty = {title:"",pillar:1,platform:"TikTok",status:"Idea",hook:"",caption:"",hashtags:"",cta:"",date:"",views:"",likes:"",comments:"",shares:"",monetize:"",revenue:"",notes:""};
  function save() {
    if (m === "add") setPosts(p => [...p, {...f, id:uid()}]);
    else setPosts(p => p.map(x => x.id === f.id ? f : x));
    setM(null);
  }
  const list = fil === "All" ? posts : posts.filter(p => p.status === fil);
  return (
    <div>
      <div className="ph"><h2>Content Planner</h2><p>Every post tracked — auto-saved.</p></div>
      <div style={{display:"flex",gap:9,flexWrap:"wrap",alignItems:"center",marginBottom:14}}>
        <button className="btn bp" onClick={() => { setF(empty); setM("add"); }}>+ New Post</button>
        <div className="tabs">{["All",...STATS].map(s => <button key={s} className={`tab${fil===s?" on":""}`} onClick={() => setFil(s)}>{s}</button>)}</div>
      </div>
      <div className="card"><div className="tw"><table>
        <thead><tr><th>Title</th><th>Pillar</th><th>Platform</th><th>Status</th><th>Date</th><th>Views</th><th>Monetize</th><th></th></tr></thead>
        <tbody>
          {list.length === 0 && <tr><td colSpan={8} style={{textAlign:"center",color:C.mu,padding:24}}>No posts yet!</td></tr>}
          {list.map(p => {
            const pl = pillars.find(x => x.id === p.pillar || x.id === Number(p.pillar));
            return (
              <tr key={p.id}>
                <td><div style={{fontWeight:600}}>{p.title}</div>{p.hook && <div style={{fontSize:10,color:C.mu,maxWidth:160,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.hook}</div>}</td>
                <td>{pl && <span className="tag" style={{background:pl.color+"20",color:pl.color}}>{pl.emoji} {pl.name}</span>}</td>
                <td style={{fontSize:11}}>{p.platform}</td>
                <td><span className="badge" style={{background:(SC[p.status]||"#888")+"20",color:SC[p.status]||"#888"}}>{p.status}</span></td>
                <td style={{fontSize:11,color:C.mu}}>{p.date||"—"}</td>
                <td style={{fontWeight:600,color:C.a3}}>{p.views||"—"}</td>
                <td>{p.monetize ? <span className="tag" style={{background:C.a4+"20",color:C.a4}}>{p.monetize}</span> : "—"}</td>
                <td>
                  <div style={{display:"flex",gap:5}}>
                    <button className="btn bg2 bsm" onClick={() => { setF({...p}); setM("edit"); }}>Edit</button>
                    <button className="btn bdn bsm" onClick={() => setPosts(x => x.filter(y => y.id !== p.id))}>✕</button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table></div></div>
      {m && <Modal title={m==="add" ? "New Post" : "Edit Post"} onClose={() => setM(null)} wide>
        <FF label="Title"><input className="inp" value={f.title||""} onChange={F("title")}/></FF>
        <div className="fr">
          <FF label="Pillar"><select className="inp" value={f.pillar||""} onChange={F("pillar")}>{pillars.map(p => <option key={p.id} value={p.id}>{p.emoji} {p.name}</option>)}</select></FF>
          <FF label="Platform"><select className="inp" value={f.platform||""} onChange={F("platform")}>{PLATS.map(p => <option key={p}>{p}</option>)}</select></FF>
        </div>
        <div className="fr">
          <FF label="Status"><select className="inp" value={f.status||""} onChange={F("status")}>{STATS.map(s => <option key={s}>{s}</option>)}</select></FF>
          <FF label="Date"><input className="inp" type="date" value={f.date||""} onChange={F("date")}/></FF>
        </div>
        <FF label="Hook"><input className="inp" value={f.hook||""} onChange={F("hook")} placeholder="First words they see..."/></FF>
        <FF label="Caption"><textarea className="inp ta" value={f.caption||""} onChange={F("caption")}/></FF>
        <div className="fr">
          <FF label="Hashtags"><input className="inp" value={f.hashtags||""} onChange={F("hashtags")}/></FF>
          <FF label="CTA"><input className="inp" value={f.cta||""} onChange={F("cta")}/></FF>
        </div>
        <div className="divx"/>
        <div style={{fontSize:10,fontWeight:700,color:C.mu,textTransform:"uppercase",letterSpacing:".08em",marginBottom:9}}>📊 Analytics</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:8,marginBottom:12}}>
          {["views","likes","comments","shares"].map(k => <div key={k}><label className="fl">{k}</label><input className="inp" value={f[k]||""} onChange={F(k)} placeholder="14.2K"/></div>)}
        </div>
        <div className="divx"/>
        <div style={{fontSize:10,fontWeight:700,color:C.mu,textTransform:"uppercase",letterSpacing:".08em",marginBottom:9}}>💰 Monetization</div>
        <div className="fr">
          <FF label="Type"><select className="inp" value={f.monetize||""} onChange={F("monetize")}><option value="">None</option>{MTYPES.map(m => <option key={m}>{m}</option>)}</select></FF>
          <FF label="Revenue ($)"><input className="inp" type="number" value={f.revenue||""} onChange={F("revenue")}/></FF>
        </div>
        <FF label="Notes"><textarea className="inp ta" value={f.notes||""} onChange={F("notes")} style={{minHeight:50}}/></FF>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save Post</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Cal({posts, pillars}) {
  const now = new Date();
  const [mo, setMo] = useState(now.getMonth());
  const [yr, setYr] = useState(now.getFullYear());
  const fd2 = new Date(yr,mo,1).getDay();
  const dim = new Date(yr,mo+1,0).getDate();
  const cells = Array(fd2).fill(null).concat(Array.from({length:dim},(_,i) => i+1));
  while (cells.length % 7 !== 0) cells.push(null);
  const MNS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const DNS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  function dp(d) {
    if (!d) return [];
    const ds = `${yr}-${String(mo+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
    return posts.filter(p => p.date === ds);
  }
  return (
    <div>
      <div className="ph"><h2>Content Calendar</h2><p>Your posting schedule at a glance.</p></div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
        <button className="btn bg2 bsm" onClick={() => { if(mo===0){setMo(11);setYr(y=>y-1);}else setMo(m=>m-1); }}>← Prev</button>
        <span style={{fontSize:18,fontWeight:700,fontFamily:"'Cormorant Garamond',serif"}}>{MNS[mo]} {yr}</span>
        <button className="btn bg2 bsm" onClick={() => { if(mo===11){setMo(0);setYr(y=>y+1);}else setMo(m=>m+1); }}>Next →</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3,marginBottom:4}}>
        {DNS.map(d => <div key={d} style={{textAlign:"center",fontSize:10,fontWeight:700,color:C.mu,padding:4}}>{d}</div>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3}}>
        {cells.map((d,i) => {
          const dps = dp(d);
          const isT = d===now.getDate() && mo===now.getMonth() && yr===now.getFullYear();
          return (
            <div key={i} style={{minHeight:72,background:C.sur,border:`1px solid ${isT?C.a1:C.bor}`,borderRadius:7,padding:5}}>
              {d && <>
                <div style={{fontSize:10,fontWeight:700,color:isT?C.a1:C.mu,marginBottom:2}}>{d}</div>
                {dps.map(p => { const pl = pillars.find(x => x.id===p.pillar||x.id===Number(p.pillar)); return <div key={p.id} style={{fontSize:9,padding:"1px 4px",borderRadius:3,marginBottom:2,background:(pl?.color||C.a1)+"20",color:pl?.color||C.a1,overflow:"hidden",whiteSpace:"nowrap",textOverflow:"ellipsis"}} title={p.title}>{pl?.emoji} {p.title}</div>; })}
              </>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Pillars({pillars, setPillars}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { if(f.id) setPillars(p=>p.map(x=>x.id===f.id?f:x)); else setPillars(p=>[...p,{...f,id:uid()}]); setM(null); }
  return (
    <div>
      <div className="ph"><h2>Content Pillars</h2><p>The buckets all your content lives in.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({name:"",color:C.a1,emoji:"📌",description:""}); setM(1); }}>+ Add Pillar</button>
      <div className="ga">
        {pillars.map(p => (
          <div className="card" key={p.id} style={{borderColor:p.color+"38"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:9}}>
              <span style={{fontSize:28}}>{p.emoji}</span>
              <div><div style={{fontSize:14,fontWeight:700,color:p.color}}>{p.name}</div><div style={{fontSize:10,color:C.mu,marginTop:2}}>{p.description}</div></div>
            </div>
            <div style={{display:"flex",gap:6}}>
              <button className="btn bg2 bsm" onClick={() => { setF({...p}); setM(1); }}>Edit</button>
              <button className="btn bdn bsm" onClick={() => setPillars(x=>x.filter(y=>y.id!==p.id))}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      {m && <Modal title={f.id?"Edit Pillar":"New Pillar"} onClose={() => setM(null)}>
        <div className="fr">
          <FF label="Emoji"><input className="inp" value={f.emoji||""} onChange={F("emoji")}/></FF>
          <FF label="Color"><input className="inp" type="color" value={f.color||C.a1} onChange={F("color")} style={{height:36,padding:2}}/></FF>
        </div>
        <FF label="Name"><input className="inp" value={f.name||""} onChange={F("name")}/></FF>
        <FF label="Description"><textarea className="inp ta" value={f.description||""} onChange={F("description")} style={{minHeight:50}}/></FF>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Scripts() {
  const [list, setList] = useLS("cos_scripts", [
    {id:1,title:"The Passenger in 14C",pillar:"Storytelling",tags:"drama,mystery",hook:"She handed me a folded note right before we landed...",body:"[AMBIENT FLIGHT SOUNDS]\n\nVO: We were 20 minutes from landing.\n\nShe was in 14C. Window seat. Hadn't touched her meal.\n\nAs I walked past, she pressed a folded napkin into my hand.\n\nThree words.\n\n*Don't land yet.*\n\nVO: Part 2 tomorrow.",cta:"Follow for Part 2 👇",notes:"Slow burn. End on cliffhanger."},
    {id:2,title:"Why I Never Eat Airplane Food",pillar:"Education",tags:"tips",hook:"8 years flying. Never once eaten the crew meal.",body:"VO: At 35,000 feet your sense of taste drops 30%.\n\nHumidity is lower than the Sahara desert.\n\nCrew meals? We know exactly when they were made.",cta:"Save this.",notes:""},
  ]);
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const [v, setV] = useState(null);
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { if(m==="add") setList(p=>[...p,{...f,id:uid()}]); else setList(p=>p.map(s=>s.id===f.id?f:s)); setM(null); }
  return (
    <div>
      <div className="ph"><h2>Script Library</h2><p>Every script organized — auto-saved.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({title:"",pillar:"",tags:"",hook:"",body:"",cta:"",notes:""}); setM("add"); }}>+ New Script</button>
      <div className="ga">
        {list.map(s => (
          <div className="card" key={s.id} style={{cursor:"pointer"}} onClick={() => setV(s)}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <span className="tag" style={{background:C.a1+"20",color:C.a1}}>{s.pillar||"Untagged"}</span>
              <button className="btn bg2 bsm" onClick={e => { e.stopPropagation(); setF({...s}); setM("edit"); }}>Edit</button>
            </div>
            <div style={{fontWeight:700,fontSize:14,marginBottom:4}}>{s.title}</div>
            <div style={{fontSize:11,color:C.mu,fontStyle:"italic"}}>"{s.hook}"</div>
          </div>
        ))}
      </div>
      {v && <Modal title={v.title} onClose={() => setV(null)} wide>
        <div style={{background:C.sur,borderRadius:8,padding:16}}>
          <div style={{fontSize:9,color:C.mu,textTransform:"uppercase",marginBottom:5}}>HOOK</div>
          <div style={{fontSize:13,fontStyle:"italic",color:C.a1,marginBottom:12}}>"{v.hook}"</div>
          <div style={{fontSize:9,color:C.mu,textTransform:"uppercase",marginBottom:5}}>SCRIPT</div>
          <div style={{fontSize:12,lineHeight:1.75,whiteSpace:"pre-wrap"}}>{v.body}</div>
          {v.cta && <><div style={{fontSize:9,color:C.mu,textTransform:"uppercase",marginTop:12,marginBottom:4}}>CTA</div><div style={{fontSize:12,color:C.a3}}>{v.cta}</div></>}
        </div>
      </Modal>}
      {m && <Modal title={m==="add"?"New Script":"Edit Script"} onClose={() => setM(null)} wide>
        <div className="fr">
          <FF label="Title"><input className="inp" value={f.title||""} onChange={F("title")}/></FF>
          <FF label="Pillar"><input className="inp" value={f.pillar||""} onChange={F("pillar")}/></FF>
        </div>
        <FF label="Tags"><input className="inp" value={f.tags||""} onChange={F("tags")}/></FF>
        <FF label="Hook"><input className="inp" value={f.hook||""} onChange={F("hook")}/></FF>
        <FF label="Full Script"><textarea className="inp ta" value={f.body||""} onChange={F("body")} style={{minHeight:180,fontFamily:"monospace",fontSize:12}}/></FF>
        <div className="fr">
          <FF label="CTA"><input className="inp" value={f.cta||""} onChange={F("cta")}/></FF>
          <FF label="Notes"><input className="inp" value={f.notes||""} onChange={F("notes")}/></FF>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Products({prods, setProds}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { const it = {...f,price:Number(f.price),sales:Number(f.sales),revenue:Number(f.revenue)}; if(m==="add") setProds(p=>[...p,{...it,id:uid()}]); else setProds(p=>p.map(x=>x.id===it.id?it:x)); setM(null); }
  const total = prods.reduce((s,p) => s+(p.revenue||0), 0);
  return (
    <div>
      <div className="ph"><h2>Products & Offers</h2><p>Every income stream — auto-saved.</p></div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
        <div style={{fontSize:24,fontWeight:700,color:C.a3,fontFamily:"'Cormorant Garamond',serif"}}>{fd(total)} <span style={{fontSize:12,color:C.mu,fontWeight:400}}>total revenue</span></div>
        <button className="btn bp" onClick={() => { setF({name:"",type:MTYPES[0],price:"",platform:"",status:"In Progress",sales:0,revenue:0,description:""}); setM("add"); }}>+ New Product</button>
      </div>
      <div className="ga">
        {prods.map(p => (
          <div className="card" key={p.id} style={{borderColor:p.status==="Live"?C.a3+"38":C.bor}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
              <span className="tag" style={{background:C.a4+"20",color:C.a4}}>{p.type}</span>
              <span className="badge" style={{background:p.status==="Live"?C.a3+"20":C.bor,color:p.status==="Live"?C.a3:C.mu}}>{p.status}</span>
            </div>
            <div style={{fontWeight:700,fontSize:14,marginBottom:3}}>{p.name}</div>
            <div style={{fontSize:11,color:C.mu,marginBottom:10}}>{p.description}</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:10}}>
              {[["Price",fd(p.price)],["Sales",fmt(p.sales)],["Revenue",fd(p.revenue)]].map(([l,v]) => (
                <div key={l} style={{textAlign:"center",background:C.sur,borderRadius:6,padding:6}}>
                  <div style={{fontSize:14,fontWeight:700,color:C.a3,fontFamily:"'Cormorant Garamond',serif"}}>{v}</div>
                  <div style={{fontSize:9,color:C.mu}}>{l}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:6}}>
              <button className="btn bg2 bsm" onClick={() => { setF({...p}); setM("edit"); }}>Edit</button>
              <button className="btn bdn bsm" onClick={() => setProds(x=>x.filter(y=>y.id!==p.id))}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      {m && <Modal title={m==="add"?"New Product":"Edit Product"} onClose={() => setM(null)}>
        <FF label="Name"><input className="inp" value={f.name||""} onChange={F("name")}/></FF>
        <div className="fr">
          <FF label="Type"><select className="inp" value={f.type||""} onChange={F("type")}>{MTYPES.map(m=><option key={m}>{m}</option>)}</select></FF>
          <FF label="Status"><select className="inp" value={f.status||""} onChange={F("status")}>{["Idea","In Progress","Live","Paused","Retired"].map(s=><option key={s}>{s}</option>)}</select></FF>
        </div>
        <FF label="Description"><textarea className="inp ta" value={f.description||""} onChange={F("description")} style={{minHeight:50}}/></FF>
        <div className="fr">
          <FF label="Price ($)"><input className="inp" type="number" value={f.price||""} onChange={F("price")}/></FF>
          <FF label="Platform"><input className="inp" value={f.platform||""} onChange={F("platform")}/></FF>
        </div>
        <div className="fr">
          <FF label="Sales"><input className="inp" type="number" value={f.sales||""} onChange={F("sales")}/></FF>
          <FF label="Revenue ($)"><input className="inp" type="number" value={f.revenue||""} onChange={F("revenue")}/></FF>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Affiliates({items, setItems}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { const it={...f,clicks:Number(f.clicks),conv:Number(f.conv),rev:Number(f.rev)}; if(!f.id) setItems(p=>[...p,{...it,id:uid()}]); else setItems(p=>p.map(i=>i.id===it.id?it:i)); setM(null); }
  return (
    <div>
      <div className="ph"><h2>Affiliate Tracker</h2><p>All partnerships — auto-saved.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({name:"",niche:"",comm:"",status:"Pending",clicks:0,conv:0,rev:0,notes:""}); setM(1); }}>+ Add Affiliate</button>
      <div className="ga">
        {items.map(a => (
          <div className="card" key={a.id}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
              <div style={{fontWeight:600,fontSize:13}}>{a.name}</div>
              <span className="badge" style={{background:a.status==="Active"?C.a3+"20":C.bor,color:a.status==="Active"?C.a3:C.mu}}>{a.status}</span>
            </div>
            <div style={{fontSize:10,color:C.mu,marginBottom:10}}>{a.niche} · {a.comm}</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:10}}>
              {[["Clicks",fmt(a.clicks)],["Conv.",fmt(a.conv)],["Revenue",fd(a.rev)]].map(([l,v]) => (
                <div key={l} style={{textAlign:"center",background:C.sur,borderRadius:6,padding:6}}>
                  <div style={{fontSize:13,fontWeight:700,color:C.a4,fontFamily:"'Cormorant Garamond',serif"}}>{v}</div>
                  <div style={{fontSize:9,color:C.mu}}>{l}</div>
                </div>
              ))}
            </div>
            {a.notes && <div style={{fontSize:10,color:C.mu,marginBottom:8}}>📝 {a.notes}</div>}
            <button className="btn bg2 bsm" onClick={() => { setF({...a}); setM(1); }}>Edit</button>
          </div>
        ))}
      </div>
      {m && <Modal title="Affiliate Program" onClose={() => setM(null)}>
        {[["name","Program Name"],["niche","Niche"],["comm","Commission Rate"]].map(([k,l]) => <FF key={k} label={l}><input className="inp" value={f[k]||""} onChange={F(k)}/></FF>)}
        <div className="fr">
          <FF label="Status"><select className="inp" value={f.status||""} onChange={F("status")}>{["Active","Pending","Paused","Rejected"].map(s=><option key={s}>{s}</option>)}</select></FF>
          <FF label="Revenue ($)"><input className="inp" type="number" value={f.rev||""} onChange={F("rev")}/></FF>
        </div>
        <FF label="Notes"><textarea className="inp ta" value={f.notes||""} onChange={F("notes")} style={{minHeight:50}}/></FF>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Deals({deals, setDeals}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { const it={...f,value:Number(f.value)}; if(!f.id) setDeals(p=>[...p,{...it,id:uid()}]); else setDeals(p=>p.map(d=>d.id===it.id?it:d)); setM(null); }
  return (
    <div>
      <div className="ph"><h2>Brand Deals</h2><p>Sponsorships and partnerships — auto-saved.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({brand:"",type:"",value:"",status:"Outreach",deliverables:"",deadline:"",contact:"",notes:""}); setM(1); }}>+ Add Deal</button>
      <div className="card"><div className="tw"><table>
        <thead><tr><th>Brand</th><th>Type</th><th>Value</th><th>Status</th><th>Deadline</th><th>Deliverables</th><th></th></tr></thead>
        <tbody>{deals.map(d => (
          <tr key={d.id}>
            <td style={{fontWeight:600}}>{d.brand}</td>
            <td style={{fontSize:11}}>{d.type}</td>
            <td style={{fontWeight:700,color:C.a3}}>{fd(d.value)}</td>
            <td><span className="badge" style={{background:d.status==="Active"?C.a3+"20":C.a4+"20",color:d.status==="Active"?C.a3:C.a4}}>{d.status}</span></td>
            <td style={{fontSize:11,color:C.mu}}>{d.deadline||"—"}</td>
            <td style={{fontSize:11}}>{d.deliverables}</td>
            <td><button className="btn bg2 bsm" onClick={() => { setF({...d}); setM(1); }}>Edit</button></td>
          </tr>
        ))}</tbody>
      </table></div></div>
      {m && <Modal title="Brand Deal" onClose={() => setM(null)}>
        <div className="fr">
          <FF label="Brand"><input className="inp" value={f.brand||""} onChange={F("brand")}/></FF>
          <FF label="Type"><input className="inp" value={f.type||""} onChange={F("type")}/></FF>
        </div>
        <div className="fr">
          <FF label="Value ($)"><input className="inp" type="number" value={f.value||""} onChange={F("value")}/></FF>
          <FF label="Status"><select className="inp" value={f.status||""} onChange={F("status")}>{["Outreach","Negotiating","Active","Completed","Declined"].map(s=><option key={s}>{s}</option>)}</select></FF>
        </div>
        <FF label="Deliverables"><textarea className="inp ta" value={f.deliverables||""} onChange={F("deliverables")} style={{minHeight:50}}/></FF>
        <div className="fr">
          <FF label="Deadline"><input className="inp" type="date" value={f.deadline||""} onChange={F("deadline")}/></FF>
          <FF label="Contact"><input className="inp" value={f.contact||""} onChange={F("contact")}/></FF>
        </div>
        <FF label="Notes"><textarea className="inp ta" value={f.notes||""} onChange={F("notes")} style={{minHeight:50}}/></FF>
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

function Revenue({entries, setEntries}) {
  const [f, setF] = useState({date:"",source:"",type:"Digital Product",amount:"",notes:""});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function add() { if(!f.amount||!f.source) return; setEntries(p=>[...p,{...f,id:uid(),amount:Number(f.amount)}]); setF({date:"",source:"",type:"Digital Product",amount:"",notes:""}); }
  const total = entries.reduce((s,e) => s+e.amount, 0);
  return (
    <div>
      <div className="ph"><h2>Revenue Tracker</h2><p>Every dollar tracked — auto-saved.</p></div>
      <div className="sg" style={{marginBottom:18}}>
        {[["💰",fd(total),"Total",C.a3],["📦",fd(entries.filter(e=>e.type==="Digital Product").reduce((s,e)=>s+e.amount,0)),"Digital",C.a1],["🔗",fd(entries.filter(e=>e.type==="Affiliate Link").reduce((s,e)=>s+e.amount,0)),"Affiliate",C.a4],["🤝",fd(entries.filter(e=>["Services","Brand Deal"].includes(e.type)).reduce((s,e)=>s+e.amount,0)),"Deals",C.a2]].map(([e,v,l,c]) => (
          <div className="sc" key={l} style={{borderColor:c+"28"}}>
            <div style={{fontSize:16,marginBottom:5}}>{e}</div>
            <div style={{fontSize:20,fontWeight:700,color:c,fontFamily:"'Cormorant Garamond',serif"}}>{v}</div>
            <div style={{fontSize:10,color:C.mu}}>{l}</div>
          </div>
        ))}
      </div>
      <div className="card" style={{marginBottom:16}}>
        <div className="ct">Log Revenue Entry</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr auto",gap:8,alignItems:"end"}}>
          <div><label className="fl">Date</label><input className="inp" type="date" value={f.date} onChange={F("date")}/></div>
          <div><label className="fl">Source</label><input className="inp" value={f.source} onChange={F("source")} placeholder="Script Bundle"/></div>
          <div><label className="fl">Type</label><select className="inp" value={f.type} onChange={F("type")}>{MTYPES.map(m=><option key={m}>{m}</option>)}</select></div>
          <div><label className="fl">Amount ($)</label><input className="inp" type="number" value={f.amount} onChange={F("amount")}/></div>
          <button className="btn bp" onClick={add}>+ Add</button>
        </div>
      </div>
      <div className="card"><div className="tw"><table>
        <thead><tr><th>Date</th><th>Source</th><th>Type</th><th>Amount</th><th>Notes</th><th></th></tr></thead>
        <tbody>{[...entries].sort((a,b)=>b.date.localeCompare(a.date)).map(e => (
          <tr key={e.id}>
            <td style={{fontSize:11,color:C.mu}}>{e.date||"—"}</td>
            <td style={{fontWeight:600}}>{e.source}</td>
            <td><span className="tag" style={{background:C.a4+"20",color:C.a4,fontSize:9}}>{e.type}</span></td>
            <td style={{fontWeight:700,color:C.a3}}>{fd(e.amount)}</td>
            <td style={{fontSize:11,color:C.mu}}>{e.notes||"—"}</td>
            <td><button className="btn bdn bsm" onClick={() => setEntries(p=>p.filter(x=>x.id!==e.id))}>✕</button></td>
          </tr>
        ))}</tbody>
      </table></div></div>
    </div>
  );
}

function Brand({brand, setBrand}) {
  const [ed, setEd] = useState(false);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  const fields = [["Brand Name","name"],["Handle","handle"],["Tagline","tagline"],["Mission","mission"],["Voice & Tone","voice"],["Audience","audience"],["Colors","colors"],["Things to Avoid","avoid"],["Hooks","hooks"],["CTAs","ctas"],["Hashtags","hashtags"],["Posting Cadence","posting"],["Unique Selling Point","usp"]];
  return (
    <div>
      <div className="ph"><h2>Brand Hub</h2><p>Your brand bible — auto-saved.</p></div>
      {!ed ? (<>
        <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({...brand}); setEd(true); }}>✏️ Edit Brand Hub</button>
        <div className="g2">{fields.map(([l,k]) => <div className="bf" key={k}><div className="bfl">{l}</div><div style={{fontSize:12,color:C.tx,lineHeight:1.45}}>{brand[k]||<span style={{color:C.mu,fontStyle:"italic"}}>Not set</span>}</div></div>)}</div>
      </>) : (<div>
        {fields.map(([l,k]) => <FF key={k} label={l}>{["mission","voice","hooks","ctas","hashtags","usp"].includes(k) ? <textarea className="inp ta" value={f[k]||""} onChange={F(k)} style={{minHeight:60}}/> : <input className="inp" value={f[k]||""} onChange={F(k)}/>}</FF>)}
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={() => { setBrand({...f}); setEd(false); }}>Save Brand Hub</button>
          <button className="btn bg2" onClick={() => setEd(false)}>Cancel</button>
        </div>
      </div>)}
    </div>
  );
}

function Personas({personas, setPersonas}) {
  const [m, setM] = useState(null);
  const [f, setF] = useState({});
  const F = k => e => setF(x => ({...x, [k]:e.target.value}));
  function save() { if(!f.id) setPersonas(p=>[...p,{...f,id:uid()}]); else setPersonas(p=>p.map(x=>x.id===f.id?f:x)); setM(null); }
  return (
    <div>
      <div className="ph"><h2>Audience Personas</h2><p>Know exactly who you're talking to — auto-saved.</p></div>
      <button className="btn bp" style={{marginBottom:18}} onClick={() => { setF({name:"",age:"",gender:"",location:"",pain:"",desires:"",content:"",buys:""}); setM(1); }}>+ New Persona</button>
      <div className="g2">
        {personas.map(p => (
          <div className="card" key={p.id} style={{borderColor:C.a1+"28"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:11}}>
              <div>
                <div style={{fontSize:17,fontWeight:700,fontFamily:"'Cormorant Garamond',serif",color:C.a1}}>{p.name}</div>
                <div style={{fontSize:11,color:C.mu}}>{p.age} · {p.gender} · {p.location}</div>
              </div>
              <button className="btn bg2 bsm" onClick={() => { setF({...p}); setM(1); }}>Edit</button>
            </div>
            {[["Pain Point",p.pain],["Desires",p.desires],["Best Content",p.content],["Likely to Buy",p.buys]].map(([l,v]) => (
              <div key={l} style={{marginBottom:7}}>
                <div style={{fontSize:9,color:C.mu,textTransform:"uppercase",letterSpacing:".08em",marginBottom:1}}>{l}</div>
                <div style={{fontSize:11}}>{v||"—"}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
      {m && <Modal title="Audience Persona" onClose={() => setM(null)}>
        {[["name","Name"],["age","Age Range"],["gender","Gender"],["location","Location"],["pain","Pain Point"],["desires","Desires"],["content","Best Content"],["buys","Likely to Buy"]].map(([k,l]) => (
          <FF key={k} label={l}>{["pain","desires","content","buys"].includes(k) ? <textarea className="inp ta" value={f[k]||""} onChange={F(k)} style={{minHeight:50}}/> : <input className="inp" value={f[k]||""} onChange={F(k)}/>}</FF>
        ))}
        <div style={{display:"flex",gap:8}}>
          <button className="btn bp" onClick={save}>Save</button>
          <button className="btn bg2" onClick={() => setM(null)}>Cancel</button>
        </div>
      </Modal>}
    </div>
  );
}

const QUICK = [
  "Write me a viral TikTok hook for a FA story",
  "Give me 5 content ideas for this week",
  "Write a caption + hashtags for a storytelling post",
  "Generate a 30-second FA fiction script",
  "What digital product should I create next?",
  "Write a pitch email to a travel brand",
  "Give me 10 viral hooks for The Crew Lounge",
  "Write a cliffhanger ending for my series",
  "How do I grow my TikTok faster?",
  "Create a 7-day content calendar",
];

const SYSTEM_PROMPT = `You are the AI Content Agent for "The Crew Lounge" (@seat1a) — a faceless TikTok/Instagram brand run by Marisol.

BRAND: Faceless flight attendant storytelling that blurs fiction and reality.
TAGLINE: "36,000 feet of unfiltered truth"
VOICE: Witty, warm, mysterious, cinematic. Never desperate. Always in control.
AUDIENCE: Women 22-38, travel lovers, aspiring FAs, drama fans.
PLATFORMS: TikTok (primary), Instagram Reels, YouTube Shorts.
HASHTAGS: #flightattendant #cabincrew #airlinelife #storytime #facelesscreator #fyp
MONETIZATION: Script bundles ($27), courses, affiliate (luggage/travel), brand deals.
FORMAT: Faceless, voiceover only, ambient sound, hotel/airplane backgrounds.

Write viral hooks, scripts, captions, hashtags, content calendars, pitch emails, and growth strategy. Always match The Crew Lounge voice. Format scripts with [SOUND] cues and VO: labels. Keep responses practical and ready to use.`;

function Agent() {
  const [msgs, setMsgs] = useLS("cos_agent_msgs", [{role:"ai", content:"Hey Marisol! 👋 I'm your AI Content Agent — built for The Crew Lounge.\n\nI can write scripts, hooks, captions, content plans, pitch emails, and more — all in your brand voice.\n\nWhat do you need today?"}]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function send(text) {
    const userMsg = text || input.trim();
    if (!userMsg) return;
    setInput("");
    const newMsgs = [...msgs, {role:"user", content:userMsg}];
    setMsgs(newMsgs);
    setLoading(true);
    try {
      const apiMsgs = newMsgs
        .filter(m => m.role !== "ai" || newMsgs.indexOf(m) === 0)
        .map(m => ({role: m.role === "user" ? "user" : "assistant", content: m.content}))
        .filter(m => m.role === "user");
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMsgs
        })
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text||"").join("") || "Sorry, something went wrong. Try again!";
      setMsgs(p => [...p, {role:"ai", content:reply}]);
    } catch(e) {
      setMsgs(p => [...p, {role:"ai", content:"Connection error. Check your internet and try again."}]);
    }
    setLoading(false);
  }

  function handleKey(e) { if(e.key==="Enter" && !e.shiftKey) { e.preventDefault(); send(undefined); } }

  return (
    <div>
      <div className="ph">
        <h2>🤖 AI Content Agent</h2>
        <p>Your personal brand assistant — writes scripts, hooks, captions, strategies for The Crew Lounge.</p>
      </div>
      <div style={{marginBottom:10}}>
        <div style={{fontSize:10,fontWeight:600,color:C.mu,textTransform:"uppercase",letterSpacing:".08em",marginBottom:7}}>Quick Actions — tap any to get started</div>
        <div>{QUICK.map(q => <button key={q} className="qb" onClick={() => send(q)}>{q}</button>)}</div>
      </div>
      <div className="chat-wrap">
        <div className="chat-msgs">
          {msgs.map((m,i) => (
            <div key={i} className={`msg ${m.role}`}>
              {m.role==="ai" && <div className="ai-label">🤖 AI Agent</div>}
              {m.content}
            </div>
          ))}
          {loading && <div className="msg ai"><div className="ai-label">🤖 AI Agent</div>Generating your content...</div>}
        </div>
        <div style={{display:"flex",gap:8,alignItems:"flex-end"}}>
          <textarea className="chat-inp" value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey} placeholder="Ask anything — write me a hook, script, caption, content plan..." rows={2}/>
          <button className="btn bp" onClick={() => send(undefined)} disabled={loading} style={{height:44,alignSelf:"flex-end"}}>{loading ? "..." : "Send ✦"}</button>
        </div>
      </div>
    </div>
  );
}

function Notes() {
  const [notes, setNotes] = useLS("cos_notes", DEF_NOTES);
  const [act, setAct] = useState(null);
  const [srch, setSrch] = useState("");
  const [f, setF] = useState({});
  const [ti, setTi] = useState("");
  function nn() { const n={id:uid(),title:"Untitled",tags:[],color:"#e8836a",pinned:false,content:"",date:new Date().toISOString().slice(0,10)}; setNotes(p=>[n,...p]); setAct(n.id); setF({...n}); }
  function sv() { setNotes(p => p.map(n => n.id===f.id ? {...f} : n)); }
  function dl(id) { setNotes(p => p.filter(n => n.id!==id)); if(act===id){setAct(null);setF({});} }
  function pin(id) { setNotes(p => p.map(n => n.id===id ? {...n,pinned:!n.pinned} : n)); if(act===id) setF(x=>({...x,pinned:!x.pinned})); }
  function addT() { const t=ti.trim(); if(!t||f.tags?.includes(t)) return; setF(x=>({...x,tags:[...(x.tags||[]),t]})); setTi(""); }
  const fil = notes.filter(n => n.title.toLowerCase().includes(srch.toLowerCase()) || n.content.toLowerCase().includes(srch.toLowerCase())).sort((a,b) => b.pinned-a.pinned);
  return (
    <div>
      <div className="ph"><h2>Smart Notes</h2><p>Your second brain — brain dumps, ideas, research. Auto-saved.</p></div>
      <div style={{display:"grid",gridTemplateColumns:"255px 1fr",gap:16,minHeight:"65vh"}}>
        <div>
          <div style={{display:"flex",gap:6,marginBottom:10}}>
            <input className="inp" value={srch} onChange={e => setSrch(e.target.value)} placeholder="🔍 Search..." style={{flex:1}}/>
            <button className="btn bp bsm" onClick={nn}>+</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {fil.length===0 && <div className="empty"><div style={{fontSize:36,marginBottom:8}}>📓</div><p style={{fontSize:12}}>No notes yet.</p></div>}
            {fil.map(n => (
              <div key={n.id} className="nc" style={{borderLeft:`3px solid ${n.color}`,background:act===n.id?C.sur:undefined}} onClick={() => { setAct(n.id); setF({...n}); }}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div style={{fontSize:13,fontWeight:600,marginBottom:4,color:act===n.id?n.color:undefined}}>{n.title}</div>
                  <div style={{display:"flex",gap:3,flexShrink:0}}>
                    <button style={{background:"none",border:"none",fontSize:12,color:n.pinned?C.a4:C.mu,cursor:"pointer"}} onClick={e => { e.stopPropagation(); pin(n.id); }}>📌</button>
                    <button style={{background:"none",border:"none",fontSize:11,color:C.dn,cursor:"pointer"}} onClick={e => { e.stopPropagation(); dl(n.id); }}>✕</button>
                  </div>
                </div>
                <div style={{fontSize:11,color:C.mu,lineHeight:1.5,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{n.content}</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:4,marginTop:6}}>{n.tags?.map(t => <span key={t} className="tag" style={{background:n.color+"20",color:n.color,fontSize:9}}>{t}</span>)}</div>
                <div style={{fontSize:9,color:C.mu,marginTop:4}}>{n.date}</div>
              </div>
            ))}
          </div>
        </div>
        {act && f.id ? (
          <div className="card" style={{borderColor:f.color+"38",display:"flex",flexDirection:"column"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:11}}>
              <input style={{flex:1,background:"none",border:"none",outline:"none",fontSize:20,fontWeight:700,fontFamily:"'Cormorant Garamond',serif",color:f.color||C.tx}} value={f.title} onChange={e => setF(x=>({...x,title:e.target.value}))} onBlur={sv} placeholder="Note title..."/>
              <input type="color" value={f.color||C.a1} onChange={e => setF(x=>({...x,color:e.target.value}))} style={{width:28,height:28,border:"none",borderRadius:5,cursor:"pointer",padding:2,background:"none"}}/>
            </div>
            <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:10}}>
              {f.tags?.map(t => <span key={t} className="tag" style={{background:f.color+"20",color:f.color}}>{t} <span style={{cursor:"pointer",marginLeft:3}} onClick={() => setF(x=>({...x,tags:x.tags.filter(y=>y!==t)}))}>✕</span></span>)}
              <div style={{display:"flex",gap:5}}>
                <input className="inp" value={ti} onChange={e => setTi(e.target.value)} onKeyDown={e => e.key==="Enter" && addT()} placeholder="+ tag" style={{width:70,padding:"2px 6px",fontSize:11}}/>
                <button className="btn bg2 bsm" onClick={addT}>Add</button>
              </div>
            </div>
            <textarea className="nce" style={{flex:1,minHeight:340,borderColor:f.color+"38"}} value={f.content} onChange={e => setF(x=>({...x,content:e.target.value}))} onBlur={sv} placeholder="Brain dump everything here..."/>
            <div style={{display:"flex",gap:8,marginTop:11}}>
              <button className="btn bp bsm" onClick={sv}>💾 Save</button>
              <button className="btn bg2 bsm" onClick={() => pin(f.id)}>{f.pinned?"Unpin":"📌 Pin"}</button>
              <button className="btn bdn bsm" onClick={() => dl(f.id)}>Delete</button>
            </div>
          </div>
        ) : (
          <div className="card" style={{display:"flex",alignItems:"center",justifyContent:"center",minHeight:260}}>
            <div className="empty">
              <div style={{fontSize:40,marginBottom:10}}>📓</div>
              <p style={{fontSize:12}}>Select a note or create a new one.</p>
              <button className="btn bp" style={{marginTop:12}} onClick={nn}>+ New Note</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [pg, setPg] = useState("dash");
  const [posts,    setPosts]    = useLS("cos_posts",    DEF_POSTS);
  const [prods,    setProds]    = useLS("cos_prods",    DEF_PRODUCTS);
  const [goals,    setGoals]    = useLS("cos_goals",    DEF_GOALS);
  const [pillars,  setPillars]  = useLS("cos_pillars",  DEF_PILLARS);
  const [affiliates, setAffiliates] = useLS("cos_affiliates", DEF_AFFILIATES);
  const [deals,    setDeals]    = useLS("cos_deals",    DEF_DEALS);
  const [revenue,  setRevenue]  = useLS("cos_revenue",  DEF_REVENUE);
  const [brand,    setBrand]    = useLS("cos_brand",    DEF_BRAND);
  const [personas, setPersonas] = useLS("cos_personas", DEF_PERSONAS);

  const pages = {
    dash:      <Dash posts={posts} prods={prods} goals={goals} nav={setPg}/>,
    goals:     <Goals goals={goals} setGoals={setGoals}/>,
    planner:   <Planner posts={posts} setPosts={setPosts} pillars={pillars}/>,
    cal:       <Cal posts={posts} pillars={pillars}/>,
    pillars:   <Pillars pillars={pillars} setPillars={setPillars}/>,
    scripts:   <Scripts/>,
    products:  <Products prods={prods} setProds={setProds}/>,
    affiliates:<Affiliates items={affiliates} setItems={setAffiliates}/>,
    deals:     <Deals deals={deals} setDeals={setDeals}/>,
    revenue:   <Revenue entries={revenue} setEntries={setRevenue}/>,
    brand:     <Brand brand={brand} setBrand={setBrand}/>,
    audience:  <Personas personas={personas} setPersonas={setPersonas}/>,
    agent:     <Agent/>,
    notes:     <Notes/>,
  };

  return (
    <>
      <style>{STYLES}</style>
      <div className="shell">
        <Sidebar pg={pg} setPg={setPg}/>
        <main className="main">
          {pages[pg] || <div className="empty"><p>Coming soon!</p></div>}
        </main>
      </div>
    </>
  );
}
